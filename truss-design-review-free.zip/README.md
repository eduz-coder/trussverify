# Truss Design Review — Full Edition (Free)

## What this is

A second set of eyes for wood truss packages, built as an AI skill. It compares
a truss layout and its profiles against the architectural and structural plans
and reports inconsistencies — with sheet references and a marked-up layout —
before the package is released for pricing or production.

This is the **full edition**: the complete rule set (14 rules) with step-by-step
procedures, formulas, thresholds, worked cases, manufacturer connector tables,
and the full marked-layout recipe. It embeds **no data from any plant**: no
company or person names, no customers, no real jobs, no internal standards.
Every plant loads its own values in its own configuration file.

It is a quality-control aid. It does **not** replace the truss design software,
the component manufacturer's engineering, the building designer, or a licensed
engineer. A qualified designer must verify every finding before changing or
releasing a design.

## Files in this package

- `SKILL.md` — the complete skill, in English. All outputs (chat summary and
  marked-layout notes) are always in English; that is fixed, not configurable.
  A short section at the top adapts the workflow when running in ChatGPT.
- `INSTALL.md` — how to set it up in Claude, Claude Code, or ChatGPT.
- `INSTRUCTIONS.txt` — short instruction text for the ChatGPT Custom GPT route.
- `plant-config.example.yaml` — per-plant configuration template: the source
  files to request from the plant, its standards, connector stock, error-notice
  contact, and thresholds. Values marked "EXAMPLE default" are editable
  examples, not any real plant's standards.
- `sample-review.md` — a sample result from a 100% fictional project.
- `LICENSE.txt` — the free-use license and disclaimer. Please read it.

## Before the first review: configure

The skill assumes nobody's data. Before the first review, the plant provides
and loads:

1. **Its standards document** (PDF, DOCX, XLSX, or a written memo/email):
   deflection limits, clearances, note policies.
2. **Its connector inventory export** (XLSX/CSV) — **optional**. Without it,
   connector checks run against the manufacturer's catalog only and stock is
   reported as "not verified."
3. **The current connector manufacturer catalog** (PDF).

Decisions that are fixed in the skill and are not changed by configuration:

- Girder bearing reactions written on the layout are **always mandatory**;
  only the extra support-note threshold is configurable.
- The seat-cut check is **conditional**: it applies only when a truss with a
  sloped bottom chord is hung in a hanger.
- Outputs are **always in English**.
- Configuration values are **never copied from one plant to another**.

## Safe use

- Test it first on a job you already know well — ideally one where an error
  once slipped through — and judge what it catches.
- Do not upload real customer plans to public demos; use fictional plans or
  plans you have written permission to share.
- Verify connector capacities against the current edition of the
  manufacturer's catalog before using them in production.

## The service

Don't want to run it yourself? The same review is offered as a done-for-you
service — you send the package, you get back the summary and the marked-up
layout: https://eduz-coder.github.io/trussverify/
