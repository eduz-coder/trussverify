# Installation

One package, three ways to run it. Pick yours.

## Option A — Claude (chat)

1. In Claude, go to **Settings -> Capabilities** and turn on
   *Code execution and file creation*.
2. Go to **Customize -> Skills -> + -> Upload a skill** and upload
   `truss-design-review-free.zip` **as-is — do not unzip it**.
   (`SKILL.md` sits at the root of the ZIP, which is what Claude expects.)
3. Make sure the skill **truss-design-review-full** is enabled.
4. Before your first real review, complete your plant configuration: open
   `plant-config.example.yaml` from the package, replace the EXAMPLE values
   with your plant's own standards and stock, and keep the file with the skill.

## Option B — Claude Code

1. Unzip the package into `~/.claude/skills/truss-design-review-full/`
   (the folder must contain `SKILL.md`).
2. Complete `plant-config.example.yaml` with your plant's data before the
   first review.

## Option C — ChatGPT (no paid plan needed)

1. Unzip the package on your computer.
2. Start a new chat and attach two files: `SKILL.md` and your completed
   `plant-config.example.yaml`.
3. Paste this line, then upload the plan set, the truss layout, and the
   profiles (all PDF):

   > Read the attached SKILL.md in full and use it as your complete review
   > rulebook. Review this truss package as a QUOTE (preliminary, pricing
   > only). Project address: <address>.

   Use **ORDER** instead of QUOTE for a production release. The project
   address is required for the location snow-load check; without it, that
   check is reported as not verified. If the layout is stamped preliminary,
   the job is treated as a QUOTE.

## Option D — ChatGPT with a paid plan (Project or Custom GPT)

- **Project:** create a Project and add `SKILL.md` and
  `plant-config.example.yaml` as project sources; then chat as in Option C.
- **Custom GPT:** create a GPT, upload `SKILL.md` and
  `plant-config.example.yaml` as **Knowledge** files, and paste the contents
  of `INSTRUCTIONS.txt` into the **Instructions** field.

## First run — suggested test

Run your first review on a finished job you know inside out — or one where an
error once slipped through and cost you. Compare what the skill finds against
what you already know. That tells you more than any demo.
