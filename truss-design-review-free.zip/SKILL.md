---
name: "truss-design-review-full"
description: "Full edition: use when a truss designer provides architectural/structural plan PDFs plus truss layout and profile PDFs from the design software (e.g., MiTek) for a second, pre-production review. This is the full edition of the truss design review skill, with the complete rule set, formulas, worked cases, and connector tables, for a plant's own use after the plant completes its configuration file. No plant data is embedded: each plant configures its own standards, stock, and contacts."
---

# Truss Design Review — Full Edition

## Purpose

Act as a second set of eyes before a wood truss package is released for pricing, production, or construction. Compare the truss layout and individual truss profiles against the architectural and structural plans, then report inconsistencies with sheet references and a marked-up layout.

This is a quality-control assistant — a **second review** to minimize errors. It does **not** replace the truss design software, the component manufacturer's engineering, the building designer, or a licensed engineer. A qualified designer must verify every finding before changing or releasing a design.

All outputs are always written in **English**: the chat summary and the marked-layout notes, for every plant. Output language is fixed, not configurable.

## Running in ChatGPT — runtime notes (read first)

This copy of the skill runs inside a ChatGPT Custom GPT (or Project), not in Claude. The engineering content is identical; only the tooling differs:

- **Read this entire file at the start of every review.** Use the code interpreter to open the file and read it in full. Do not rely on knowledge-retrieval snippets, search results, or memory of previous conversations: the rules, thresholds, and tables must come from this file, every time. Also open `plant-config.example.yaml` and use its values.
- **Text extraction:** this environment has no `pdftotext` or `pdftoppm`. Use Python instead — `pdfplumber` (text and word bounding boxes) or `pypdf` — wherever the reading method below names those tools. For reading dimensions and graphics, view the PDF pages directly as rendered by the platform; if a label or dimension still cannot be read reliably, report that it could not be read — never guess (same rule as the reading method below).
- **Marked layout PDF:** first try PyMuPDF (`import fitz`) and follow the recipe in "How to make the marked layout" exactly. If PyMuPDF is not available — expected in this sandbox, where packages cannot be installed — use this fallback with the same layout, colors, numbering, side panel, and tables page: locate each finding with `pdfplumber` word bounding boxes (mind each page's rotation value; pdfplumber coordinates start at the top-left, PyMuPDF's at the top-left as well but its rotation handling differs — convert carefully); build the output page (original layout at its viewing orientation on the left, ~600 pt notes panel on the right) as an overlay with `reportlab` (numbered circles, leader lines, dashed rectangles, panel text, tables), and merge it with the source page using `pypdf`. Then re-open the result and visually check that marks land on the right elements and no labels are covered, exactly as the recipe requires. If the fallback also fails, state plainly that the marked PDF could not be generated in this environment and deliver instead the complete numbered findings as a table keyed to layout locations (truss/girder labels and dimensions) — never silently skip the deliverable.
- **Saving outputs:** save deliverables in the working folder (`/mnt/data`) and provide download links, using the filenames specified under Deliverables.
- Everything else in this file — rules, thresholds, tables, outputs, communication rules — applies unchanged.

## Core principles

**Principle 1 — Always verify the design against the plans.** Each plan governs: dimensions, overhangs, pitches, ceilings, heights, foundation, floor depth and spacing, deflection, and loads are taken from that job's plan — never from habit or from another job. **If the plan contradicts itself** (for example, the "Roof Truss Spec's" table says heel 12" but the knee-wall or ceiling heights cannot be achieved with that heel), that is a **High-priority finding**: never silently pick one value. Room heights (knee wall, ceiling, cathedral) are what the customer expects to see — see Rule 9.

**Principle 2 — Review EVERY sheet of the plan and EVERY section or detail that refers to trusses (Rule 13).** The floor plan, elevations, and one building section are not enough. Open every sheet (architecture and structure), read every note and legend, and follow every mark and every section or detail callout (for example "6/S3.4") to the sheet where it lives. Anything the plan requires of the truss supplier that is not in the layout or the profiles **is always reported**, even on a preliminary/pricing package.

**Principle 3 — Always report every error and missing item to the designer.** On every review, the chat summary must state clearly what is wrong and what is missing (even if it is minor), plus which sheets were reviewed. If nothing was found, say that too, with the list of sheets reviewed.

## Plant configuration

This skill embeds **no plant data**. Before the first review for a plant, request these source files and record the values in the plant's configuration file (`plant-config.example.yaml`):

1. **Plant standards document** — PDF, DOCX, XLSX, or a written memo/email stating the plant's own criteria (for example: floor deflection limit, raised-bearing clearance, note and callout policies). If the plant has no written standard for a check, mark the affected items **Confirm** instead of inventing one.
2. **Connector inventory export (optional)** — XLSX or CSV exported from the plant's inventory system, or the plant's own hanger allowable-loads spreadsheet. Columns needed: connector model, fastener schedule, allowable download and uplift by lumber species group and load duration. This file is optional: if it is not provided, check connector demand against the manufacturer catalog only and state in the report that plant stock was **not verified**.
3. **Manufacturer connector catalog** — current-edition PDF from the connector manufacturer (for example, Simpson Strong-Tie or MiTek USP). Used for connector dimensions, minimum heel requirements, fastener schedules, and special-order options when no stocked connector works.

Configuration rules:

- Never copy configuration values from one plant to another. Each plant's standards, stock list, thresholds, and contacts are its own.
- **Girder bearing reaction callouts on the layout are always mandatory** (Rule 7). Only the extra support-note threshold is configurable.
- The **seat-cut check is conditional** (Rule 8): it applies only when a truss with a sloped bottom chord is hung in a hanger.
- If a required configuration value is missing, label the related item **Confirm** instead of inventing a standard.

## Preliminary vs. order packages

If the job is **preliminary (pricing only)**, apply all the rules the same way, but order the findings by what changes the price (special orders, loads, drift, special/sheathed gables, bearings, overhangs, depth, spacing, material quantity), and mark the layout "PRELIMINARY". Items that are only needed for the order (for example, Rule 8, or the girder loads written on the layout) are reported as **"for the order"**.

## Starting a review: job stage

The job stage decides how strictly the findings are graded, so it is fixed **before** the review starts:

1. **The user declares the stage when submitting the package**, in one line — QUOTE (preliminary / pricing only) or ORDER (production release) — together with the project address. The starter line looks like one of these:
   - "Review this truss package as a QUOTE (preliminary, pricing only). Project address: <address>."
   - "Review this truss package as an ORDER (production release). Project address: <address>."
2. If the layout itself is stamped or marked preliminary, treat the job as a **QUOTE** even if the user did not state the stage.
3. If the stage is neither stated nor visible anywhere in the files, **ask once before reviewing — never guess.**

What changes with the stage: on a **QUOTE**, findings are ordered by price impact, the marked layout is labeled PRELIMINARY, and order-only items (girder bearing callouts written on the layout, the seat-cut correction, the held-up hanger note) are reported as **"for the order"** instead of High. On an **ORDER**, full strictness applies and those same items are **High**.

## Files expected

1. The architectural and structural plans (PDF): floor plans, elevations, building sections, eave details, foundation plan or section, roof framing plan, schedules (gable truss, girder truss support, holdowns, hangers), design notes (snow, drift, wind loads), floor notes (depth, spacing, deflection, I-joists or floor trusses), and the "Roof Truss Spec's" table if there is one.
2. The truss layout PDF from the design software, roof and floor if there are both.
3. The truss profile PDFs (one page per truss), including the girders.
4. Optional: Material Summary, supplier drawings (tall walls, beams), and emails with answers from the customer or salesperson.
5. **Project address (street, city, state, ZIP).** Snow and wind loads are location-dependent. Without an address, the location check (see "Loads" in the full review checklist) cannot be performed and must be reported as not verified.

If any file is missing, say so and review with what is available. If two files are identical, say so. If a file that should contain profiles is actually something else (for example, an Itemized Estimate instead of the floor truss profiles), say so and ask for the profiles. If the plan set has no structural (S) sheets and the job has an engineer of record, ask about it.

## How to read the files

- Extract the text of the design-software PDFs with `pdftotext -layout`: they contain real text (loads, spacing, CSI, deflections, reactions, lumber, notes, and WARNINGs). The drawing dimensions (heel, overhang, heights, depth, seat cut, bearing blocks, bottom-chord start) **do not come out in the text** — they must be read from images.
- Convert pages to images with `pdftoppm` and zoom (150–200 dpi, cropped regions; 400–500 dpi for the ends of floor trusses) to read dimensions, labels, eave details, and the plan's specification table. For jobs with many trusses, build contact sheets of 4–6 profiles per image to compare heels, heights, and overhangs quickly.
- Search the profile text for all "WARNING", "fail", "req.", "No Soln", and "Hanger(s) or other connection device(s)" notes.
- In the plan: extract the text of **every page** (`pdftotext -f N -l N`) to build the sheet inventory (Rule 13) and search for keywords: TRUSS, GABLE, GT-, SGT-, DT-, GIRDER, DRIFT, PSF, OVERFRAM, VALLEY, DORMER, HEEL, HEAL, OVERHANG, FASCIA, HOLDOWN, SHEAR WALL, "BY TRUSS", "TRUSS SUPPLIER", "TRUSS MANUFACTURER". Sheets may be rotated (PyMuPDF: `page.rotation`); to crop a region use `page.search_for()` and `rect * page.rotation_matrix`.
- If a label cannot be read reliably, say so. **Never guess.**

## Main rules (errors that have already happened in the field)

### Rule 1: Compare the trusses against each other

**Field case:** In one job, a group of trusses had the bottom chord starting at 0-7-4 and another group at 0-5-8. That produced heel 2-4-0 against 2-2-8 and overall height 13-6-10 against 13-5-2, and a 1-1/2" step showed up in the roof in the field. Each truss was fine by itself; the error is only visible by comparing them.

On every job, compare all trusses that bear on the same wall or sit next to each other: left and right heel, overall height, bottom-chord peak, bottom-chord start, and overhangs. On floors: depth, chords, and bearing heights (Rule 11). On lay-in gables: height against the tallest truss (Rule 12).

- Any difference between neighboring trusses is a **High-priority finding**, even 1/8".
- Also compare the heel against what the plan requires (for example, "Heel height: 24""), and on attic or knee-wall trusses verify that the heel actually produces the plan's room heights (Rule 9).
- On roofs with several pitches (hip), verify that the fascia tip lands at the same elevation everywhere: heel − overhang × pitch must come out the same on all faces.

### Rule 2: Everything released must carry dimensions

Before release, check every page that will be sent (layout and any plan or drawing) and confirm it has:

- Overall dimensions (building length and width).
- Truss spacing (for example, 2-00-00 or 1-07-03) along the whole layout.
- Location, with dimensions, of roof changes, porches, cantilevers, girders, stair openings, and headers.
- Overhang dimensions.
- A note stating what the dimensions reference (for example, "to face of stud").
- Job name, job number, date, and who drew it. On floors, the depth (for example, 16").

If a page has no dimensions, it is a **High-priority finding**: it does not go out that way. On a preliminary package, if the designer states that dimensions between trusses do not matter, do not check them.

### Rule 3: Check hanger capacity against the plant's stock

The design software sizes the hangers, but always check them again.

1. Pull each hung truss's reaction from the software: maximum download (Max Grav) and maximum uplift (Max Uplift). Also compare the hung truss's reaction against the load applied to the girder: if they do not match, the girder must be re-run.
2. Check the lumber of the girder chord where the hanger mounts (for example, "SP 2400F" or "SPF No.2") to pick the DF/SP or the SPF/HF column. If the hung truss is SPF, also use the SPF/HF column.
3. Pick the load-duration column:
   - Roofs with snow (duration factor 1.15): **Snow (115)**.
   - Floors: Floor (100).
   - Roofs without snow: Roof (125).
   - Uplift: Uplift (160).
4. Use the table that matches how the hanger is installed: **SD screws** (Table A) or **nails** (Table B). If unknown, check against both and use the lower value. SD screws and nails **cannot be mixed in the same hanger** (Simpson C-C-2026, p. 26, note 5).
5. If any load exceeds capacity, it is a **High-priority finding**: propose the next stocked model that works.
6. Confirm the hanger will be installed with the fasteners in the table (count and model).
7. **If the hanger needed is not in stock** (different model, different size, skewed, sloped, or nothing reaches capacity): it is not an error, but a **special order must be suggested**. Look in the C-C-2026 (Plated Truss Connectors section) for options that reach capacity, with their catalog page, and request the data still needed (girder plies and lumber, vertical web size, uplift, hung truss heel). When the software specifies non-stock hangers, also suggest switching them to a stocked equivalent when capacity allows.

**Worked tables.** The tables below use an **example stock set** — HUS26, HUS28, HUS26-2, HUS28-2 — so the procedure can be shown with real numbers. **Replace this stock set with your plant's own stock list in the plant configuration**; the capacities are manufacturer-published values (Simpson Strong-Tie C-C-2026 and strongtie.com/sd) and must be re-verified against the current catalog edition before use.

**Table A: with SD10212 screws (allowable loads, lb)**

Source: a plant hanger allowable-loads spreadsheet, transcribed from strongtie.com/sd. These values **do not appear in the C-C-2026 catalog**: for double-shear hangers such as the HUS, the catalog refers the user to strongtie.com/sd for SD-screw loads (p. 26, note 4). What the C-C-2026 does verify (p. 381) is the total SD10212 count: HUS26 (20), HUS28 (30), HUS26-2 (8), HUS28-2 (12), which matches this table. Note an anomaly: in the HUS26-2 and HUS28-2 rows, the SPF/HF download column is **higher** than the DF/SP column, which is unusual — **verify these two rows at strongtie.com/sd and flag every job where one of those two rows is used** until the values are confirmed.

| Model | Joist screws | Face screws | DF/SP Uplift (160) | DF/SP Floor (100) | DF/SP Snow (115) | DF/SP Roof (125) | SPF/HF Uplift (160) | SPF/HF Floor (100) | SPF/HF Snow (115) | SPF/HF Roof (125) |
|---|---|---|---|---|---|---|---|---|---|---|
| HUS26 | (6) SD10212 | (14) SD10212 | 860 | 3400 | 3400 | 3400 | 740 | 2815 | 2920 | 2920 |
| HUS28 | (8) SD10212 | (22) SD10212 | 1490 | 4180 | 4180 | 4180 | 1280 | 3145 | 3340 | 3475 |
| HUS26-2 | (4) SD10212 | (4) SD10212 | 1375 | 860 | 990 | 1075 | 1260 | 1010 | 1160 | 1265 |
| HUS28-2 | (6) SD10212 | (6) SD10212 | 1950 | 1970 | 2265 | 2460 | 1680 | 1515 | 1745 | 1895 |

**Table B: with 0.162" x 3-1/2" nails (allowable loads, lb), Simpson C-C-2026**

HUS26 and HUS28: Plated Truss Connectors section, p. 220. HUS26-2 and HUS28-2: Solid Sawn Lumber section, p. 114 (DF/SP) and p. 119 (SPF/HF).

| Model | Face nails | Joist nails | DF Uplift | DF Floor | DF Snow | DF Roof | SP Uplift | SP Floor | SP Snow | SP Roof | SPF/HF Uplift | SPF/HF Floor | SPF/HF Snow | SPF/HF Roof |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HUS26 | (14) | (6) | 1,320 | 2,735 | 3,095 | 3,235 | 1,320 | 2,960 | 3,280 | 3,280 | 1,150 | 2,350 | 2,660 | 2,780 |
| HUS28 | (22) | (8) | 1,760 | 4,095 | 4,095 | 4,095 | 1,760 | 4,095 | 4,095 | 4,095 | 1,480 | 3,520 | 3,520 | 3,520 |
| HUS26-2 | (4) | (4) | 1,165 | 1,090 | 1,225 | 1,320 | 1,165 | 1,090 | 1,225 | 1,320 | 1,000 | 935 | 1,055 | 1,135 |
| HUS28-2 | (6) | (6) | 1,320 | 1,630 | 1,840 | 1,980 | 1,320 | 1,630 | 1,840 | 1,980 | 1,135 | 1,400 | 1,580 | 1,705 |

(On the HUS26-2 and HUS28-2 rows, p. 114 publishes a single value for DF/SP.)

**C-C-2026 notes that must be applied (p. 221, Plated Truss):**

- Nail loads assume a girder of **at least 2 plies**. If the girder is a single 2x ply, nails must be 0.148" x 1-1/2" on the face and the load is **multiplied by 0.64 (x 0.64)**. Always flag this.
- Cross-grain tension in the truss chord (ANSI/TPI 1) can limit the load. Simpson's Hanger Selector (app.strongtie.com/hs) does evaluate it.
- Uplift already includes the wind/seismic increase; do not increase it further.
- HUS hangers cannot be used sloped or skewed; a different model is required (special order).

**HUS26-2 and HUS28-2 in trusses:** in the C-C-2026 these two appear in the solid-sawn tables (pp. 114 and 119), not in the Plated Truss section (pp. 220–221). For 2-ply trusses hung from a girder, that section shows HHUS26-2 and HHUS28-2. When a job uses HUS26-2 or HUS28-2 truss-to-truss, flag that it should be confirmed with the truss software maker or Simpson; if it cannot be confirmed, suggest a special order of the HHUS model.

**Special-order options for large loads on 2-ply trusses (C-C-2026, Snow 115)** — quick reference; always confirm with the job's data:

| Hanger | DF/SP | SPF/HF | Uplift DF/SP / SPF | Condition | Page |
|---|---|---|---|---|---|
| HGUS28-2 | 7,460 | 6,415 | 3,235 / 2,780 | Minimum heel 6-9/16"; nails | p. 221 |
| HGUS210-2 | 9,100 | 7,825 | 4,095 / 3,520 | Minimum heel 8-9/16"; nails | p. 221 |
| THGQ2-SDS3 (Max), 2x8 web | 12,435 | 9,660 | 4,535 / 3,900 | Centered on a 2x8 vertical web; with a 2x6 web it drops to 9,770 / 7,590 | p. 238 |
| THGQH2-SDS3 (Min), 2x8 web | 11,950 | 9,660 | 3,875 / 3,335 | H = 25" | p. 238 |
| HTHGQ2-SDS | 18,010 | 12,520 | 3,940 / 3,390 | Girder of at least 3 plies and a 2x10 web | p. 238 |

**Bearing uplift clips (tie-downs at bearings):** each plant must add its own clip table to its configuration — the clip models stocked, their capacities, and their catalog source. If a bearing needs a clip that is not in stock, suggest a special order (same handling as hangers).

### Rule 4: Check that the hangers actually fit

Capacity can pass and the hanger still not fit: sometimes there is no room between one truss and the next to install it. If the software says "manually applied but fail due to geometric considerations" or the layout says "No Soln", it is a **High-priority finding**.

**Dimensions of the hangers in the example stock set (Simpson C-C-2026)** — replace with your plant's stock models in the plant configuration:

| Model | Gauge | W (seat) | H (height) | B (depth) | Minimum heel of the hung truss | Overall width with flanges | Page |
|---|---|---|---|---|---|---|---|
| HUS26 | 16 | 1-5/8" | 5-3/8" | 3" | 4-5/16" | 5-5/8" | p. 220 |
| HUS28 | 16 | 1-5/8" | 7" | 3" | 6-1/2" | 5-5/8" | p. 220 |
| HUS26-2 | 14 | 3-1/8" | 5-3/16" | 2" | not published (solid-sawn table) | approx. 7-1/8" | pp. 114 / 119 |
| HUS28-2 | 14 | 3-1/8" | 7-3/16" | 2" | not published (solid-sawn table) | approx. 7-1/8" | pp. 114 / 119 |

Overall width = W + 2 flanges of 2" (2" flanges for 2x per the figures on pp. 112 and 219). On HUS26-2 and HUS28-2 the flange width is not dimensioned in their table: treat it as approximate.

On every girder with hangers, check:

1. **Space between neighboring hangers.** Using the layout and the locations in the software's notes, measure the center-to-center distance between hangers on the same face of the girder and compare it with the total width of the two hangers (half of each). If the flanges overlap or there is no room for the fasteners, it is a **High-priority finding**.
2. **Hangers on both faces of the girder at the same point.** SD10212 screws are 2-1/2" long and face nails are 3-1/2". In a 2-ply girder (3" thick) the fasteners from one side and the other can clash. Flag it and suggest staggering the hangers or confirming with the manufacturer.
3. **Plies of the girder.** The nail loads assume a girder of at least 2 plies (see the note in Rule 3). Also confirm the ply-to-ply connection the software requires.
4. **Hanger height against the girder's bottom chord.** The face fasteners must land in the girder's bottom chord (for example, a 2x8 measures 7-1/4"). If H is greater than the chord, flag it.
5. **Heel of the hung truss.** The heel of the hung truss must be at least the table's "minimum heel" to develop the full load. If it is less, the capacity drops (Simpson, bulletin T-C-REDHEEL). Flag it.
6. **Hanger height against the depth of the hung truss.** Simpson recommends that the hanger height be at least 60% of the depth of the joist/truss so it does not rotate during construction (C-C-2026, p. 23, note m).
7. **Plates and webs of the girder.** Check in the girder's profile whether a plate or a web at the hanger point interferes with the fasteners or the hanger. THGQ/HTHGQ hangers are centered on a vertical web of the girder; if the SDS screws pass through a plate, the holes must be pre-drilled (5/32" maximum) and the designer must approve it (p. 238).
8. **Seat width.** A 1-ply truss takes a single hanger (HUS26, HUS28); a 2-ply truss takes a -2 hanger.
9. **Seat cut of the hung truss.** See Rule 8.

### Rule 5: When the designer reports an error or a repair, prepare the notification draft

**This rule activates only when the designer reports** that there was an error, or that there is a problem that must be resolved with a repair. Never send a notification on your own based on the findings of a review: those are corrected before release.

The plant's error-notification contact (name and email in the plant configuration) is the role that absorbs the cost of errors, so they must always be notified.

When the designer reports an error or a repair:

1. Ask for whatever is missing to understand the problem: customer, job number, affected trusses, what happened (photos if there are any), and whether the job is already in production, delivered, or installed in the field.
2. If it is a **repair**, help define it with what is available (truss profile, reactions, photos). The final repair must be approved by the truss manufacturer's engineer; make that clear. If a truss was already cut or modified in the field (for example, a bottom chord that was trimmed), note that this also needs the engineer's approval.
3. Prepare a **draft email** for the configured error-notification contact, for the designer to review and send. **Never send it**: draft only. It must include:
   - Customer, job number, and salesperson.
   - What happened and which trusses or pieces it affects.
   - The cause of the error, in one or two lines.
   - How it will be corrected (repair, new trusses, extra pieces).
   - Estimated cost, or "[cost to be confirmed]" if it is not known. Never invent figures.
   - What was changed so it does not happen again (for example, a new rule in this skill).
4. Add the error to "Lessons learned" and, if applicable, propose a new rule.

### Rule 6: Overhangs are always verified against the plan

The overhang always depends on that job's plan. There is no fixed rule (for example, "always without fascia"): read what that plan says.

**Field case:** In one job, the trusses had an overhang of 1-4-12, which was the plan's **total** dimension (1'-4 3/4" = 1'-2 1/2" to the tail + 2-1/4" of fascia). The tail should have been 1-2-8: every overhang came out 2-1/4" too long. It was confirmed as a real error.

On every job:

1. Look in the plan for the eave details, the elevations, and the specification table (for example, "O.H.'s (including 2x6 fascia): 16"").
2. Determine exactly what the plan measures: to the tail of the truss, to the face of the fascia, from the face of stud, or from the sheathing. Also check whether the overhang or the gutter is "field built" (in that case, confirm whether the trusses carry a tail or are cut flush).
3. With that, compute the overhang the truss should have and compare it with every truss in the software (the end dimensions, for example -1-4-12). Do it for **every pitch and every face** (eave and gable).
4. If they do not match, it is a **High-priority finding**.
5. If the plan does not make clear what the dimension includes, mark it **Confirm**.

### Rule 7: Girder loads go on the layout (support note at or above 14,000 lb)

The builder has to know where the heavy loads land. That is why:

1. Pull from the software the maximum load at each bearing of **every girder** (Max Grav; if there is none, the reaction). Ends hung in hangers ("Mechanical") are checked with Rule 3, not here.
2. Confirm that each of those loads is **written on the layout** at its bearing (for example, "11,740#"). Locate on the layout where each bearing is (with the girder's position and length) **before** saying a load is missing or a number does not match. Locate **both ends of every girder** first.
   - **Field case (false alarm):** a 5,099 lb reaction was first reported as missing, but it was on the layout as 6,000# at the girder's other end. Before saying a load is missing, locate both ends of every girder on the layout.
   - If one is missing, it is a **High-priority finding** (on a preliminary package, "for the order").
   - The layout number must be equal to or greater than the software value (round up). If the layout says less (for example, 7,100# for 7,164 lb), flag it.
   - If there is a number on the layout that matches no girder, flag it for confirmation.
3. **If the load is at or above the configured high-reaction threshold** (plant configuration; default 14,000 lb), or very high for the bearing, the layout must also carry a **support note** in this form (with the job's actual number): "COLUMN TO SUPPORT 14,020# DIRECTLY UNDER TRUSS BEARING AND THROUGH TOP PLATES." If the note is missing, it is a **High-priority finding**. Also check the spelling of the note (on one real job it read "COLUM").
4. Check that the bearing is sufficient: if the software says "req." greater than the available bearing width, flag it together with the load.
5. If the plan has notes for the floor or beam design (for example, "floor truss design must account for concentrated point loads") or a "Girder Truss Support Schedule", note that these loads must be passed to whoever designs the floor, the beams, or the posts. If a roof girder load lands on the end of a floor truss, call for squash blocks and a continuous post to the foundation.

### Rule 8: Minimum 3" seat cut on hung trusses with a sloped bottom chord

This check is **conditional**: it applies only when a truss with a sloped bottom chord (scissor, vault, cathedral ceiling) is hung in a hanger. The tip of the bottom chord is cut to make a flat seat (seat cut), and that seat must be long enough for the truss to bear in the hanger.

**Field case:** A hung truss with a 7/12 bottom chord, an end 5-01-11 high, a reaction of 2,073 lb / -187 lb, and a seat of only **0-2-9** (2-9/16"): it does not reach 3".

On every truss hung in a hanger with a sloped bottom chord:

1. Read in the profile (image) the horizontal dimension of the flat seat at the hung end.
2. The seat must measure **at least 3"** (manufacturer's requirement). Also compare it with the seat depth B of the hanger (HUS26/HUS28: 3"; HUS26-2/HUS28-2: 2"; HGUS: 4"): use whichever is greater. Confirm with the manufacturer if in doubt.
3. If the seat is less:
   - On a **preliminary package (quote)**: report it as "for the order", not High.
   - On an **order**: it is a **High-priority finding**. The truss must be corrected (lengthen the seat cut) and the note added to the layout.
4. When the hanger is held up to receive the seat cut, the layout must carry this note at that point, with the real dimensions of each case:
   - **"HANGER HELD UP 0'-X"-X ABOVE BOTTOM OF GIRDER BOTTOM CHORD. 3" MIN. SEAT CUT ON TRUSS."**
5. If the note is missing on an order, it is a **High-priority finding**.

### Rule 9: On attic / knee-wall trusses, verify the heel against the knee-wall height

**Field case:** In one job, the plan's "Roof Truss Spec's" table said **heel 12"** and the truss was designed at 1-0-0. But the plan called for a knee wall at 5'-0" from the exterior wall with a **5'-6 1/8" ceiling** and a flat ceiling about 7'-6" wide at 8'-1 1/8" (10/12). With a 12" heel, the truss gave only **~3'-7" clear** at the knee wall and 2-8-0 of flat ceiling. It went out wrong on the order. **The plan's heel value was wrong; only the knee wall showed it was not 12".** The heel that was needed was ~2'-11".

On every attic, room-in-attic, or bonus-room truss, or any truss with a knee wall or a cathedral ceiling that starts at a wall, **do not trust the heel in the plan's table alone**. Verify it against the room heights:

1. Find in the plan (upper floor plan, sections, and elevations): the knee-wall location (distance from the exterior face), the ceiling height at the knee wall ("CLG. HT."), the flat-ceiling height, the room width, where the ceiling changes from cathedral to flat, and the pitch.
2. Compute the clear height at the knee wall from the truss data:
   - **Clear height ≈ heel + x × (pitch/12) − vertical depth of the TC − depth of the room's BC**, where x = horizontal distance from the point where the heel is measured to the face of the knee wall.
   - Vertical depth of the TC = lumber depth ÷ cos(angle). For 10/12 (cos 0.768): 2x6 = 7.16", 2x8 = 9.44", 2x10 = 12.04". For other pitches: cos = 12 / √(12² + pitch²).
   - Depth of the room's BC: the floor chord of the room (B2), for example 2x10 = 9.25". If the plan measures from the finished floor, also subtract the subfloor (~3/4").
3. Do the same with the flat ceiling: the collar height (the software's dimension, for example 8-1-14 from the BC) against the plan's, and the **width of the flat ceiling** in the truss (between the joints where the collar starts) against the plan's.
4. If the knee-wall height or the flat-ceiling width does not match the plan (by more than ~1"), it is a **High-priority finding**, even if the heel matches the table. Compute and report both ways out:
   - **Required heel** = plan knee-wall height + BC depth + TC vertical depth − x × pitch/12.
   - Or where the knee wall would have to go (and the room width that would result) keeping the heel.
5. The plan contradicts itself: do not choose silently. The room heights are what the customer expects to see, so **by default the knee wall and the ceilings govern** over the heel in the table; mark it to confirm with the salesperson or the customer before release. Remember that a taller heel changes the overall height, the overhangs (fascia tip), the gables, the stairs, and the price.
6. Also check the stair headroom if the stairs arrive under the slope.

### Rule 12: Lay-in gables cannot be taller than the tallest truss in the job

A lay-in gable (a gable that is "laid in" on top of the main roof trusses — for example at a roof change, an overframe, a pediment over a hip, or a dormer) **cannot be taller than the tallest truss in the job**. This is a plant standard; confirm the value in the plant configuration.

On every job with lay-in gables:

1. Identify them in the profiles and on the layout: Truss Type "Lay-In Gable" (or similar), labels such as LG / LIG, or gables that bear on the top chord of other trusses instead of on a wall.
2. Read the **overall height** of each lay-in gable in its profile (the overall vertical dimension, for example 8-6-3) and the overall height of **every other truss** in the job (the overall vertical dimension; on common roofs, that of the longest-span truss).
3. Find the **tallest truss in the job** (the greatest overall height among all profiles, not counting the lay-in gables).
4. If the height of any lay-in gable **is greater** than that of the tallest truss, it is a **High-priority finding**: report both numbers (for example, "LG01 9-2-4 vs T05 8-11-10, the tallest") and the difference. It must be lowered or split (for example, into two pieces or with a cap) in the software.
5. Also check, with the layout and the pitches, that the ridge of the lay-in gable does not sit above the ridge of the main roof it bears on; if it cannot be confirmed with the data, mark it **Confirm**.
6. If the height is right at the limit (equal or within 1/2"), flag it as **Medium** for the designer to review.

### Rule 13: Review every sheet, every note, and every section of the plan

**Field case:** A structural roof framing plan marked a spanning gable truss (SGT-A) over a 19'-8" shear wall, with a "Gable Truss @ Shear Wall" section and a Gable Truss Schedule (verticals @ 24" o.c., OSB 7/16" on one side, 8d @ 6" at edges with blocking / 12" in the field, 2 holdowns, base to the wall 16d @ 6" o.c.). On the layout, that truss was a common. The review missed it because the mark was not followed to its section. On the same sheet there were also a **snow drift** (56 psf → 25.2 psf at 7'-0") and **overframing @ 2'-0" o.c.** where the new roof ties into the existing one, neither of which was in the design.

On every job:

1. **Sheet inventory.** List every page of the plan with its number and name (A1, A3, S1.3, S3.4...). Review them all, including the structural, foundation, and detail sheets, even if they seem unrelated to trusses. Report the list of sheets reviewed in the chat.
2. **Legends and marks on the structural plan.** Read the legend ("Wood Framing Plan Legend") and find on the floor plan every truss-related mark: GT-X (gable truss), SGT-X (spanning gable truss), DT-X (drag truss), GIRDER TRUSS, GTS (girder truss support), holdowns, hangers, blocking ("D"), shear walls (WSW) under trusses, "OVERFRAMING", valleys, loads in psf or lb, "SNOW DRIFT".
3. **Follow every section or detail callout** (for example "1/S3.4", "6/S3.4", "2/S3.3", "TYP. 1/A6") to its sheet and read it in full: which truss it carries, sheathing, verticals, holdowns, anchorage, blocking, out-of-plane wind bracing, heel, overhang.
4. **Schedules.** Read every schedule that mentions trusses (Gable Truss Schedule, Girder Truss Support Schedule, Holdown, Hanger, Wood Blocking) and compare it row by row with the layout and the profiles.
5. **General and design notes** (S0.x sheets and the notes on each sheet): design loads (TCLL, TCDL, BCDL, Pg, Pf, Ps, drift, wind), "truss supplier shall...", "field verify...", connection requirements (a holdown clip at every truss, clips at hips, girder ties). Report whatever affects the price or whatever the plant has to supply.
6. **Compare against the design.** Everything the plan requires that is not in the layout or the profiles (a special truss, a load, a valley/overframing, a dormer, a sheathed gable, a holdown, a vertical to transfer forces) is a **finding**: **High** if it changes the structure or the price; **Confirm** if it may be field framed or by others.
7. **Report it even on a preliminary package.** A missing plan item changes material and price.

### Rule 14: Special plan loads (snow drift, sliding, unbalanced, equipment)

**Field case:** A structural plan marked snow drift on the lower garage roof next to a two-story wall — 56 psf at the wall, tapering to the balanced 25.2 psf at 7'-0" — and no profile carried that load.

On every job:

1. Look in the structural plan and the design notes for any special load: drift (at roof level changes, next to tall walls, parapets, chimneys), sliding snow, unbalanced snow, equipment (HVAC, solar panels), storage areas.
2. Check in the profiles whether the software carries it (search for "drift", "Trapezoidal", "surcharge", or user loads in the load cases). If it is not there, it is a **High-priority finding**.
3. Compute the load that falls on each affected truss and deliver it in psf and in plf:
   - Determine whether the plan's value at the wall is the **total snow** (balanced + drift) or only the drift: if the plan shows the balanced Ps at the end of the strip (for example, 25.2 psf = the Ps from the notes), the value at the wall is the total.
   - Verify with ASCE 7-16: γ = 0.13·Pg + 14 ≤ 30 pcf; hd = pd / γ; wd = 4·hd (when hd ≤ the available height). It should reproduce the plan's width.
   - Load at a distance d from the wall (linear): p(d) = p_wall − (p_wall − p_balanced) · d / wd.
   - Extra for the software = p(d) − the snow the software already used (for example, Pf 30 with Cs 1.0 = 30 psf). If it comes out negative, nothing is needed.
   - plf = psf × spacing (24" o.c. = × 2).
   - If the trusses run **parallel** to the wall, each truss carries a uniform load over its whole length, and the value depends on its distance from the wall. If they run **perpendicular**, each truss carries a trapezoidal load over the wd strip next to the wall.
4. Deliver a table per truss (distance to the wall, total psf, extra psf, extra plf) and recommend running the highest value for all trusses in the strip if that is simpler.

## Floor truss rules

On every job with floor trusses, apply Rules 10 and 11 in addition to the general rules (2, 3, 4, 7, 13). In the plan, look for the floor notes: depth, spacing, deflection (for example, "I-joists ... w/ L/600 minimum live load deflection"), floor type (tile, stone, zero-entry shower), foundation, and wall heights.

### Rule 10: Floor trusses with a raised bearing (dropped / bearing blocks): the bottom chord must not hit the foundation

**Field case:** In one job, the floor trusses bore on bearing blocks (BL1) with the bearing at **0-8-0** above the bottom of the bottom chord (the truss drops 8" into the foundation), a bearing length of 0-5-8, and the bottom chord starting only **0-6-0** from the end of the truss. The foundation wall was thicker than that, so **the bottom chord hit the foundation** and had to be cut in the field. A "minor" error, but a real one.

On every floor truss (and any truss) whose bottom chord sits **below the bearing** (bearing blocks, dropped bearing, top chord bearing, bearing on a ledger, or on a wall with the truss dropping alongside it):

1. Detect it in the profile (image): "BL" blocks at the end, a vertical dimension at the end (for example 0-8-0 or 0-9-8) from the bottom of the BC to the bearing, and the note "Bearing at joint(s) ... considers parallel to grain value".
2. Read in the profile the **horizontal distance from the end of the truss to where the bottom chord starts** (the bottom dimension, for example 0-6-0) at each end.
3. Find in the plan (foundation plan, sections, details) the **thickness of the foundation wall** and how the sill sits (flush outside, centered, with or without a rim), and measure from the same point as the end of the truss. If the plan does not say, ask and mark it **Confirm** (never assume a thickness).
4. **Plant standard (from the plant configuration; default 1/2"):** the bottom chord must start beyond the inside face of the foundation with at least that clearance. Required BC start = distance from the end of the truss to the inside face of the foundation + clearance. If the start is less, it is a **High-priority finding** (on a preliminary package, "for the order"): lengthen the bottom-chord setback in the software (or change the bearing detail) and re-run.
5. Check the same at interior raised bearings (load-bearing walls, beams, foundation walls between garage and house, ledgers), and that the part that drops does not clash with anchors, beams, or ducts shown in the plan.
6. If the bottom chord was already cut in the field, it is a repair: it needs the truss manufacturer's engineer's approval, and the notification draft is prepared (Rule 5).

### Rule 11: Floor depth, spacing, deflection, and chords per the design

The floor is what the customer walks on every day: if it bounces or the tile cracks, it becomes a complaint. That is why, on every floor truss, check:

1. **Depth.** Read in each profile the overall height (vertical dimension, for example 1-4-0 = 16") and compare it with:
   - What the plan requires (floor note, section, "16" floor trusses", or the depth of the I-joists being replaced).
   - The heights that depend on the floor: floor-to-floor, the stairs (number of risers and riser height), wall heights and basement ceiling heights, ducts.
   - The neighboring trusses: **every truss in one floor must have the same depth** unless the plan calls for something else (shower drops, sunken areas). If one truss is different without a reason, it is **High priority**.
   - If the plan does not state the depth, mark it **Confirm**.
2. **Spacing.** The "Spacing" in the software profile (for example, 1-7-3 = 19.2", 1-4-0 = 16", 2-0-0 = 24") must be:
   - Equal to the plan's (if it states one) and to what was drawn on the layout (measure with the layout's scale).
   - The same on every truss in the floor, with the girders carrying the spacing or load that actually falls on them.
   - Compatible with the plan's subfloor (for example, 23/32" OSB at 19.2" or 24"; confirm against the plant standard).
   - If the profile spacing does not match the layout or the plan, it is **High priority**: the loads and the deflection are computed wrong.
3. **Deflection (the most important floor check).**
   - **Limit:** compare against the **stricter** of the plan requirement and the plant standard in the plant configuration. The configuration ships with a default example of **L/600 minimum live load** on all floors, even if the plan does not state it; if the plan requires something stricter (for example, L/720 for stone), the plan governs.
   - Pull Vert(LL) and Vert(CT) from the profile: inches, l/defl, and L/d (the limit the software used, for example 360 and 240).
   - Compare the **real l/defl of Vert(LL)** against the configured limit (default L/600, or the plan's), **not against the L/d the software used**. The software often runs with L/360 and reports OK even though it does not reach L/600. Any floor truss or girder with a Vert(LL) below the limit is **High priority**.
   - Best practice is to run the software with L/d = 600 in live load; if the profile shows L/d 360, flag it so the criterion is changed in the software.
   - Also report the total deflection Vert(CT) in inches; flag it as **Confirm** if it exceeds ~3/4".
   - Floors with tile or stone (bathrooms, kitchens, zero-entry showers): flag them if they land near the limit.
   - Always report the deflection in inches and in L/ for the longest trusses and for the girders. If it does not pass: propose more depth, tighter spacing, or higher-grade chords (2100F/2400F), and re-run.
   - **Field case:** 16" deep floor trusses at 19.2" o.c., span 23-11-2: two trusses gave L/515 (-0.55") and L/524 (-0.54"), with -0.75" total. The software said OK because it used L/360; against the L/600 standard they do not pass. A floor girder gave L/633 (barely passes).
4. **Top and bottom chords per the design.**
   - Check in LUMBER the size, the orientation (for example, 2x4 flat / 4x2), and the grade of the TOP CHORD and BOT CHORD of each truss against what the plan or the job specification requires.
   - Every truss in one floor must have **the same chord width and orientation** (the subfloor and the ceiling below bear on them); a chord of a different width, or set on edge, in a single truss is **High priority**. Grade changes (No.2 vs 2100F 1.8E) can vary; report them only if they do not match what the plan requires.
   - Top-chord drops for showers or tile: verify the dimension against the layout note and the plan, that the drop is on the correct side (painted end), and that the neighbors in the same room have the same drop.
   - Check that the "*Except*" segments in LUMBER (a chord segment of a different grade) are in the place where the software needs them and do not change the chord width.
5. **CSI and floor notes:** flag CSI ≥ 0.95; review "Load case(s) has/have been modified" (verify the modified loads are the intended ones); strongbacks (2x6 at 10'-0" o.c. — include them in the material if the plant configuration says the plant supplies them); and "Do not erect truss backwards" (the layout must mark the painted end).
6. **Floor girders and headers:** applied loads against the reactions of the trusses they carry (Rule 3), the location of the load against the layout, and the stair-opening header defined (size and connection).

## Full review (after the main rules)

**Plan vs layout**
- Sheet inventory and follow-up of every section (Rule 13).
- Overall dimensions and dimensions to the face of stud.
- Load-bearing walls, shear walls under trusses (gable/sheathed truss), beams, posts, and cantilevers.
- Pitches and ceiling type (flat, cathedral, tray, scissor, attic). On attic or knee-wall trusses, apply Rule 9.
- Eave and gable overhangs per Rule 6.
- Wall height used. If the plan lists more than one, confirm which applies, and verify that wall + bottom-chord peak gives the plan's ceiling height.
- Additions to existing houses: "match existing" / "field verify" notes for pitch, heel, overhang, and ridge height; overframing or valleys where the new roof ties into the existing one; infill framing.
- Dormers, gable features, cupolas, or any roof element in the elevations that is not on the layout.
- Foundation: wall thickness and sill position against the ends of the floor trusses (Rule 10).
- Floors: depth, spacing, deflection (configured live-load limit) and chords per Rule 11.
- Openings in the floor of an attic room (stairs): the length of the opening must be the length of the stair, not including the landing or closets. **Field case:** in one job the opening ran to 19' while the stair ended at ~11'-4", leaving the landing and a closet without floor.

**Geometry**
- Gables at the ends and at roof changes, with studs where they are needed.
- The plan's special gable trusses (GT, SGT, DT): sheathing, verticals, holdowns, and wall connection per the schedule (Rule 13).
- Lay-in gables: no taller than the tallest truss in the job (Rule 12).
- Tall walls or supplier walls: how the end truss bears.
- Openings: chimneys, skylights, attic hatches. Look for dashed rectangles or notes in the plan that are not on the layout.
- Odd pitches in the profiles (for example, 12.53/12 where it should be 10/12). On lay-in gables over hips and on corner jacks, the truss's own pitch is legitimately different (for example, 8.5/12 → 6.01/12 on the corner jack): not an error.

**Loads**
- TCLL, TCDL, BCDL, spacing, and DOL per the plan's design table or notes.
- **Location check (address-based):** the project address is a required input. Verify the snow load against the project address using the applicable published source — the state code's snow zone map where one exists (example: Wisconsin Uniform Dwelling Code, SPS 321 Fig. 321.B2, roof snow Zone 1 = 40 psf / Zone 2 = 30 psf for one- and two-family dwellings), or the ASCE 7 Hazard Tool (ground snow Pg by address). If the plan's snow value conflicts with the value for the project location, report it as a **High-priority finding** with both values and the source. If the plan states no snow load, use the location value only as a reference and mark the item **Confirm** — never silently substitute it as the design criterion. Without an address, report the location check as not verified.
- Snow, Ct, and wind reasonable for the zone.
- Special loads: drift, sliding, loft, equipment, habitable attic, tile or stone on floors (Rule 14).

**Software results**
- CSI of TC, BC, and WB below 1.0. Flag those at 0.95 or more (or the configured CSI threshold).
- Vertical deflection against the plan's limit (on floors, the configured live-load limit, Rule 11).
- Horizontal deflection, especially on cathedral and scissor trusses. Compare against the plant limit; if it is not known, flag as **Confirm** when it exceeds 3/4".
- All WARNING notes resolved.

**Bearings and connections**
- Bearing width: if the software says "req." greater than the available bearing, it is **High priority**.
- Girder loads on the layout per Rule 7.
- Large reactions from ordinary trusses: flag for header and beam review (for example, cantilevered porches).
- Maximum uplift against the capacity of the tie clip. Connectors the plan calls for at each truss, hip, or girder: flag whether the plant quotes/supplies them.
- Hangers per Rules 3, 4, and 8.

**Package**
- Report quantities equal to the trusses on the layout: count positions, look for doubles or missing ones. Profiles that do not appear on the layout (for example, default names such as R1001) are **always flagged**: they can be a double count in the quote. **Field case:** in one job an orphan profile was identical to a lay-in gable that was already on the layout.
- Layout labels equal to the profile names.
- Layout, profiles, and Material Summary from the same run (same job number and date).

## Deliverables (always, on every review)

There is no Word checklist. Exactly two things are delivered:

1. **In the chat**, a short summary in English:
   - Whether it can be released or not.
   - **Errors and missing items**: the important points (usually 3–6), numbered to match the marked layout. Always include what the plan requires and is missing from the design (Rule 13). If there is nothing, say so.
   - One line with the **sheets reviewed** (for example: "Sheets reviewed: A1–A6, S0.1–S3.4 — 23 sheets").
2. **The marked layout (PDF)**, which is the main deliverable. See "How to make the marked layout" below.

Mark as **Confirm** whatever depends on plant standards that are not known, or whatever may be field framed / by others, instead of calling it wrong. Only when the designer reports an error or a repair: the notification draft (Rule 5).

Save the PDF in the outputs folder with the name `<Customer>_<job>_layout_reviewed.pdf` (add `_prelim` if it is preliminary).

## How to make the marked layout

It is a PDF copy of the software's layout with the corrections written on top of it. It is not a software file and it does not change the original: the real changes are made by the designer in the design software.

**Page 1: marked layout**

- The complete original layout (vector) at the left.
- A **notes panel at the right** (about 600 pt wide): title "REVIEW - <Customer> <job>" (+ "(PRELIMINARY)" if applicable), one line with the color legend, and, for each finding, its number in a circle and the short note (what is wrong, with the exact numbers from the software or the plan, the plan sheet/section it comes from, and what to do). At the foot: "Second review: does not replace the design software's calculations or the engineer."
- On the drawing: a **numbered circle** with a leader line to the point, and a **dashed rectangle** (cloud) around what is wrong.
- Colors: **red** = High priority; **orange** = Medium or "for the order"; **blue** = low priority or Confirm.
- Order the numbers by priority (the main rules first).
- If a finding applies to many trusses (for example, all the overhangs), mark 2 or 3 representative points and explain it in the panel.
- In crowded areas, put the circle to one side with a long leader line, without covering labels or dimensions.
- If there is more than one layout (roof and floor), one marked page per layout, with the same numbering.

**Final page (only if there is data for it): supporting tables**, the same size as page 1:

- **Girder loads (Rule 7):** girder, bearing, software load, layout load, is it there?, does it need a note (≥ threshold)?, does it have the note?
- **Hangers (Rules 3, 4, and 8):** girder, hung truss, location, download / uplift, hanger, capacity (SD or nails), does it pass?, does it fit?, seat cut, stock or special order.
- **Knee wall and ceilings (Rule 9), if there are attic trusses:** plan vs truss knee-wall height, flat ceiling (height and width) plan vs truss, table heel vs required heel.
- **Lay-in gables (Rule 12), if there are any:** lay-in gable, its height, the tallest truss in the job and its height, difference, does it pass?
- **Special loads (Rule 14), if there are any:** truss, distance to the wall, total load psf, extra psf, extra plf.
- **Plan items (Rule 13):** mark or note from the plan, sheet/section, what it requires, is it in the design?
- **Floor trusses (Rules 10 and 11), if there is a floor:** truss, length, depth (plan / truss), spacing (plan / layout / profile), TC and BC (size, orientation, grade), Vert(LL) in inches and L/, against the configured deflection limit, does it pass?, Vert(CT), raised bearing, BC start against the foundation + clearance.
- **What does match the plan:** a short list (dimensions, pitches, ceilings, overhangs, loads, etc.).

**How to do it (PyMuPDF; install with `pip install pymupdf --break-system-packages`):**

1. Open the layout. Design-software layouts usually arrive with the page rotated (`page.rotation = 90`; they can be letter size 612 x 792 or 1296 x 1728, and they display in landscape).
2. Locate each truss, girder, load ("#"), and note with `page.get_text('words')`, and convert each rectangle to the visible orientation with `fitz.Rect(w[:4]) * page.rotation_matrix`.
3. Create a new page of visible width + 600 pt. Set the original's rotation to 0 (`src[0].set_rotation(0)`) and place the layout with `new_page.show_pdf_page(fitz.Rect(0,0,W,H), src, 0, rotate=-90)` (adjust the sign if it comes out upside down). Then you can draw on top in normal visible coordinates.
4. To locate points along a girder (for example, a hanger at 7-7-12 from the end), use the layout's scale: length of an overall dimension in pt ÷ its measurement in feet. Keep in mind which end the software measures from ("from the left end" of the profile, which can be the other side on the layout). To locate plan elements (walls, drift strips) on the layout, use the same scale and a common reference wall.
5. Draw with `draw_circle`, `draw_line`, `draw_rect(..., dashes="[4 2] 0")`, `insert_text`, and `insert_textbox` (fonts "helv"/"hebo"; avoid characters outside Latin-1, such as arrows). In the tables, `insert_textbox` writes nothing if the text does not fit in the cell: shorten the text or widen the column, and check that no cells are left empty.
6. **Review the result as an image** (render at 50–75 dpi for the whole page and at 110 dpi for the marked areas) and move anything that covers labels or sits far from its point before delivering.

## Lessons learned

Every time the designer reports a new field error or a false alarm, add it here and, if applicable, as a new rule.

- A 1-1/2" step in the roof from a heel difference between groups of trusses (bottom chord starting at 0-5-8 vs 0-7-4). See Rule 1.
- Sheets sent out without dimensions. See Rule 2.
- Hanger stock set; whatever is not in stock is suggested as a special order. Nail loads and dimensions verified in the C-C-2026. The SD-screw loads come from strongtie.com/sd, not from the catalog. The bearing uplift clips still have to be added by the plant. See Rules 3 and 4.
- Sometimes there is no physical space between trusses to install the hanger. See Rule 4.
- When the designer reports an error or a repair, the notification draft is prepared for the configured error-notification contact, who absorbs the cost. See Rule 5.
- Overhang: the trusses shipped at 1-4-12 when the tail should have been 1-2-8 (the plan gave 1'-4 3/4" including 2-1/4" of fascia). Confirmed as a real error. The overhang always depends on the plan. See Rule 6.
- Girder loads must be on the layout; at or above the threshold, with the support note for the builder ("COLUMN TO SUPPORT 14,020# DIRECTLY UNDER TRUSS BEARING AND THROUGH TOP PLATES."). See Rule 7.
- A 5,099 lb girder load was first reported as missing, but it was on the layout as 6,000# at the girder's other end. Before saying a load is missing, locate both ends of every girder on the layout. See Rule 7.
- A hung truss arrived at the hanger with a seat cut of 0-2-9 (less than 3"). On a quote it does not matter; on the order it is corrected and the held-up hanger note is added. See Rule 8.
- The marked layout PDF is always delivered: it is the fastest way for the designer to locate the errors. The Word checklist was eliminated; its tables moved to the tables page of the PDF.
- **Knee wall came out wrong on an order.** The plan's table said heel 12" and it was designed that way, but the plan called for a knee wall of 5'-6 1/8" at 5'-0" from the wall (10/12, flat ceiling at 8'-1 1/8"). With 12" the knee wall gave ~3'-7"; a heel of ~2'-11" was needed. Only the knee wall showed that the plan's heel was wrong. See Rule 9.
- The stair opening in the floor of an attic room ran to 19' and left the landing and a closet without floor; the stair ended at ~11'-4". See "Plan vs layout".
- A file named "Floor Truss profiles" was actually the Itemized Estimate, not the profiles. Always flag when a file is not what its name says.
- **The bottom chord of the floor trusses hit the foundation.** Bearing on bearing blocks at 0-8-0 above the bottom of the BC, with the BC starting at 0-6-0 from the end; the foundation was thicker and the bottom chord was cut in the field. Plant clearance standard: 1/2" minimum (from the plant configuration). See Rule 10.
- Floor trusses gave L/515 and L/524 live load (the software passed them with L/360). Floor standard: the configured live-load deflection limit (default L/600). On floors, deflection matters as much as spacing, depth, and the top and bottom chords being per the design. See Rule 11.
- Lay-in gables: the height cannot exceed the tallest truss in the job. See Rule 12.
- **A spanning gable truss was missed.** The structural plan marked it over a 19'-8" shear wall, with its own section and a Gable Truss Schedule (OSB 7/16" one side, verticals @ 24", 2 holdowns). On the layout it was a common truss. The review did not follow the mark to its section. From now on, every sheet, every note, and every section is reviewed. See Rule 13.
- The same plan called for snow drift on a lower roof (56 psf → 25.2 psf at 7'-0" next to the two-story wall) and overframing @ 2'-0" o.c. where the new roof ties into the existing one; neither was in the design. See Rules 13 and 14.
- There were profiles that were not on the layout (default names); one of them was identical to a lay-in gable already on the layout. Always flag them: possible double count in the quote.

## Communication rules

- Report facts and document references before opinions.
- Quote dimensions exactly as shown; preserve the source format when useful.
- Distinguish a plan requirement, a configured plant standard, a software result, and a reviewer inference.
- Never invent a missing dimension, load, capacity, cost, or approval.
- Never send external messages or notifications. Drafts only, and they require human review and the recipient configured in the plant configuration.
- When the user reports a new field error, a false alarm, a plant standard, or a stock change, propose updating this skill and its "Lessons learned" section so it is saved for the next review.

## Completion statement

End every review with:

- Sheets reviewed.
- Files reviewed.
- Configuration values used or missing.
- Findings by severity.
- A reminder that a qualified truss designer must verify the results in the design software before release.
