# Sample Review — Fictional Project

**Project:** Maple Street Residence — Demo  
**Package:** Roof truss layout and profiles  
**Recommendation:** Do not release yet  
**Sheets reviewed:** A1–A4, S1.0–S2.1 (fictional demo set)  
**Configuration:** Example plant configuration; no real plant standards or inventory

> This sample is entirely fictional. Names, dimensions, and findings were created to demonstrate the reporting format.

## Findings

### 1 — High — Overhang does not match the plan

The structural eave detail dimensions the truss tail to 1'-2 1/2" from the wall reference line. Representative profiles show a 1'-4 1/4" tail.

**Difference:** 1 3/4"  
**Action:** Confirm the plan reference, correct the affected trusses, and rerun the profiles.

### 2 — High — Plan-required special truss is shown as a common truss

Sheet S2.0 and its referenced detail call for a spanning gable truss at the labeled shear wall, including specified sheathing and holdown requirements. The layout label at that location corresponds to a common truss profile.

**Action:** Change the truss type and apply the schedule and detail requirements before release.

### 3 — Medium — Girder bearing callout is missing

A girder profile reports a maximum gravity reaction of 9,840 lb at its left bearing. No matching reaction callout was found at that bearing on the layout.

**Action:** Add the rounded-up reaction at the correct bearing and verify the support below.

### 4 — Confirm — Connector demand exceeds the configured example inventory

A supported truss reaction exceeds the verified capacity entered for the stocked example connector under the applicable load-duration case. The physical fit and seat cut also require confirmation.

**Action:** Select a manufacturer-approved connector using the plant's current catalog data or place a special order. Do not release with the example connector.

### 5 — Medium — Floor deflection is below the configured limit

The fictional example configuration requires L/480 minimum for floor live-load deflection. One fictional floor profile reports L/420.

**Action:** Increase depth, reduce spacing, revise chord specification, or use another design option approved by the designer, then rerun.

## Items verified

- Building overall dimensions match the architectural plan.
- Main roof pitch matches the elevations.
- Layout labels match the supplied profile names.
- No duplicate profile was found in the fictional package.

## Demo note

Second review only. A qualified truss designer must verify every finding in the design software before changing or releasing the package. This sample does not replace engineering review.
